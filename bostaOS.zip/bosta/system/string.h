#ifndef STRING_H
#define STRING_H
#include "types.h"
void *memset(void *dest, int value, size_t count);
char *strcpy(char *dest, const char *src);

#endif

