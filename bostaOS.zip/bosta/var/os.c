#include <system/input.h>
int run() {
    while(1){
        char c = input();   // lê uma tecla
        print_char(c);  
        if (c == "0") {
            print_string(c);
        }   // mostra a tecla lida
    }
}

